<?php
session_start();
?>
<?php
include 'opendb.php';


$qiqi= mysql_query("select * from depend WHERE policyNo = '$_SESSION[username]'")or die(mysql_error());
while ($taf=mysql_fetch_array($qiqi)){
$nem=$taf['name'];
$sirname=$taf['surname'];
$policyNo=$taf['policyNo'];
$rship=$taf['rship'];


$rer= mysql_query("select * from subscriber WHERE reg = '$_SESSION[username]'")or die(mysql_error());
while ($ter=mysql_fetch_array($rer)){
$name=$ter['name'];
$surname=$ter['surname'];
$fone=$ter['fone'];
$email=$ter['email'];
$policy=$ter['policy'];
$add=$ter['address'];
$pik=$ter['pathe'];
$reg=$ter['reg'];

$rr= mysql_query("select * from policy WHERE type = '$policy'")or die(mysql_error());
while ($tr=mysql_fetch_array($rr)){
$id=$tr['id'];
$type=$tr['type'];
$premium=$tr['premium'];
$cover=$tr['cover'];
                        
			$dependents = mysql_num_rows($qiqi);
			$mari = $dependents * $premium;
			
					$date = date("Y-m-d");
					date_default_timezone_set("Africa/Harare");
						
					$time = date("h:i:sa");
			mysql_query("insert into premium values('','$reg','$rship','$premium','$cover','$date','$time')")or die(mysql_error());
				
					
			}
	
}}

?>
        <script language="javascript">
		alert("Payment successful..!");
		location = 'index.php'
		</script>	








