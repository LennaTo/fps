<?php 
session_start();
$username=$_SESSION['username'];
if(isset($_POST['submit']))
{
$con = mysql_connect("localhost","root","");
if (!$con)
  {
  die('Could not connect: ' . mysql_error());
  }

mysql_select_db("fps", $con);
	//$date = date("Y-m-d");
date_default_timezone_set("Africa/Harare");
						
//$time = date("h:i:sa");
$zuva=date('Y-m-d H:i:s');

		$message=$_POST['message'];
		$sender=$_POST['sender'];
		$time=$zuva;
		mysql_query("INSERT INTO mesg(id, name, msg, time)VALUES('', '$sender', '$message', '$zuva')");
}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<center><img src="../images/log.jpg" /></center>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<center><ul class="art-hmenu"></center>
		<li>
			<center><a href="../admin/index.php"><strong><h2>Home</strong></h2></a></center>
		</li>	
	</ul></center>
	</div>
</div>
</div>
</div>
</div>

<title>Online Chat</title>
<script language="javascript" src="jquery-1.2.6.min.js"></script>
<script language="javascript" src="jquery.timers-1.0.0.js"></script>
<script type="text/javascript">

$(document).ready(function(){
   var j = jQuery.noConflict();
	j(document).ready(function()
	{
		j(".refresh").everyTime(1000,function(i){
			j.ajax({
			  url: "refresh.php",
			  cache: false,
			  success: function(html){
				j(".refresh").html(html);
			  }
			})
		})
		
	});
	j(document).ready(function() {
			j('#post_button').click(function() {
				$text = $('#post_text').val();
				j.ajax({
					type: "POST",
					cache: false,
					url: "save.php",
					data: "text="+$text,
					success: function(data) {
						alert('data has been stored to database');
					}
				});
			});
		});
   j('.refresh').css({color:"green"});
});
</script>
<style type="text/css">
.refresh {
    border: 1px solid #3366FF;
	border-left: 4px solid #3366FF;
    color: green;
    font-family: tahoma;
    font-size: 12px;
    height: 225px;
    overflow: auto;
    width: 400px;
	padding:10px;
	background-color:#FFFFFF;
}
#post_button{
	border: 1px solid #3366FF;
	background-color:#3366FF;
	width: 100px;
	color:#FFFFFF;
	font-weight: bold;
	margin-left: -105px; padding-top: 4px; padding-bottom: 4px;
	cursor:pointer;
}
#textb{
	border: 1px solid #3366FF;
	border-left: 4px solid #3366FF;
	width: 320px;
	margin-top: 10px; padding-top: 5px; padding-bottom: 5px; padding-left: 5px; width: 415px;
}
#texta{
	border: 1px solid #3366FF;
	border-left: 4px solid #3366FF;
	width: 410px;
	margin-bottom: 10px;
	padding:5px;
}
p{
border-top: 1px solid #EEEEEE;
margin-top: 0px; margin-bottom: 5px; padding-top: 5px;
}
span{
	font-weight: bold;
	color: #3B5998;
}
</style>
</head>
<center><h2>Online Chat </h2></center>
<br />

<body bgcolor="#A7A7A7">
<center><form method="POST" name="" action="">
<center><input name="sender" type="text" id="texta" value="<?php
include '../opendb.php';
$result = mysql_query("SELECT * FROM users where username = '$_SESSION[username]'")or die(mysql_error());
while ($ter=mysql_fetch_array($result)){
$name=$ter['name'];
$surname=$ter['surname'];}
 echo $name." ".$surname; ?>"/></center>
<center><div class="refresh">
<?php

?>

</div></center>
<center><input name="message" type="text" id="textb" placeholder="Type Message Here" /></center>
<br />
<center><input name="submit" type="submit" value="Chat" id="post_button" /></center>
</form></center>
</body>
<marquee direction="left" >Hardwork**Hope**Excellence**</marquee>
</html>
