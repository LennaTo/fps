<?php

session_start();	
include '../opendb.php';

		$access = 3;
	mysql_query("INSERT INTO users (name,surname,contact,email,sex,access,username,password,id)
VALUES
('$_POST[name]','$_POST[surname]','$_POST[contact]','$_POST[email]','$_POST[sex]','$access','$_POST[username]','$_POST[password]','')") or die (mysql_error());
		?>
        <script language="javascript">
		alert("Details successfully uploaded");
		location = 'index.php'
		</script>
        
        <?php
	
