<?php
session_start();	
include '../opendb.php';
$rer= mysql_query("select * from users WHERE username = '$_SESSION[username]'")or die(mysql_error());
while ($ter=mysql_fetch_array($rer)){
$company=$ter['company'];
$name=$ter['name'];
$surname=$ter['surname'];
$contact=$ter['contact'];
$email=$ter['email'];
$sex=$ter['sex'];
$username=$ter['username'];
$password=$ter['password'];
$id=$ter['id'];
		
$rr= mysql_query("select * from company WHERE name like '%".$company."%'")or die(mysql_error());
while ($tr=mysql_fetch_array($rr)){
$id=$tr['id'];
$name=$tr['name'];
$suffix=$tr['suffix'];
$phone=$tr['phone'];
$address=$tr['address'];

if (!isset($_FILES['files']['tmp_name'])) {
	echo "shame";
	}else{
	$file=$_FILES['files']['tmp_name'];
	$image= addslashes(file_get_contents($_FILES['files']['tmp_name']));
	$image_name= addslashes($_FILES['files']['name']);
	$image_size= getimagesize($_FILES['files']['tmp_name']);

	
		
			move_uploaded_file($_FILES["files"]["tmp_name"],"../subscriber/images/" . $_FILES["files"]["name"]);
			
			$location="../subscriber/images/" . $_FILES["files"]["name"];
			$myn = "Owner";

	mysql_query("INSERT INTO subscriber (reg,name,surname,sex,fone,address,user,password,email,policy,company,pathe,agent)
VALUES
('$_POST[reg]','$_POST[name]','$_POST[surname]','$_POST[sex]','$_POST[fone]','$_POST[address]','$_POST[user]','$_POST[password]','$_POST[email]','$_POST[policy]','$company','$location','$username')") or die (mysql_error());

mysql_query("INSERT INTO depend (id,policyNo,name,surname,rship,policy)
VALUES
('','$_POST[reg]','$_POST[name]','$_POST[surname]','$myn','$_POST[policy]')") or die (mysql_error());


}}}
		?>
        <script language="javascript">
		alert("Details successfully uploaded");
		location = 'index.php'
		</script>
        
	
