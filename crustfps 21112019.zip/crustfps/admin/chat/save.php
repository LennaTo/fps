<?php

if (isset($_POST['text'])) {

$con = mysql_connect("localhost","root","");
if (!$con)
  {
  die('Could not connect: ' . mysql_error());
  }

mysql_select_db("fps", $con);

$ddd=$_POST['text'];
	$query = "INSERT INTO mesg (msg) VALUES ('$ddd')";
	
}

?>