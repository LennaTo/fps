<?php
session_start();	
include '../opendb.php';

		
	mysql_query("INSERT INTO company (id,name,suffix,phone,address)
VALUES
('','$_POST[name]','$_POST[surname]','$_POST[contact]','$_POST[address]')") or die (mysql_error());
		?>
        <script language="javascript">
		alert("Details successfully uploaded");
		location = 'index.php'
		</script>
        
        <?php
	
