<?php
$con = mysql_connect("localhost","root","");
if (!$con)
  {
  die('Could not connect: ' . mysql_error());
  }

mysql_select_db("fps", $con);
date_default_timezone_set("Africa/Harare");
$zuva=date('Y-m-d');
$time=$zuva;
$tim = date("h:i:sa");
$result = mysql_query("SELECT * FROM mesg ORDER BY id DESC");


while($row = mysql_fetch_array($result))
  {
  echo '<p>'.'<span>'.$row['name'].'</span>'. '&nbsp;&nbsp;' . $row['msg'].'&nbsp;&nbsp;' .'&nbsp;&nbsp;'.'&nbsp;&nbsp;'.'&nbsp;&nbsp;'.'&nbsp;&nbsp;'. $row['time'].'</p>';
  }
echo $zuva. "    ".$tim;
mysql_close($con);
?>
