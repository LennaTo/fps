<?php

session_start();	
include '../opendb.php';
	

$rer= mysql_query("select * from users WHERE username = '$_SESSION[username]'")or die(mysql_error());
while ($ter=mysql_fetch_array($rer)){
$company=$ter['company'];
$name=$ter['name'];
$surname=$ter['surname'];
$contact=$ter['contact'];
$email=$ter['email'];
$sex=$ter['sex'];
$username=$ter['username'];
$password=$ter['password'];
$id=$ter['id'];

		mysql_query("INSERT INTO users (company,name,surname,contact,email,sex,access,username,password,id)
VALUES
('$company','$_POST[name]','$_POST[surname]','$_POST[contact]','$_POST[email]','$_POST[sex]','$_POST[access]','$_POST[username]','$_POST[password]','')") or die (mysql_error()); }
		?>
        <script language="javascript">
		alert("Details successfully uploaded");
		location = 'index.php'
		</script>
        
        
	
