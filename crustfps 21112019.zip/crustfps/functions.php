<?php

function clean($str) {
                            $str = @trim($str);
                            if (get_magic_quotes_gpc()) {
                                $str = stripslashes($str);
                            }
                            return mysql_real_escape_string($str);
                        }
						
/*function username_exists($username){
	$username = sanitize($username);
	return(mysql_result(mysql_query("SELECT COUNT(`username`) FROM `users` WHERE `username` = '$username'"), 0) == 1)? true : false;	
}*/
                        ?>