<?php

mysql_connect("localhost","root","") or die(mysql_error());
mysql_select_db("fps") or die(mysql_error());
session_start();	
include '../opendb.php';

		
	mysql_query("INSERT INTO users (company, name,surname,contact,email,sex,access,username,password,id)
VALUES
('$_POST[company]','$_POST[name]','$_POST[surname]','$_POST[contact]','$_POST[email]','$_POST[sex]','$_POST[access]','$_POST[username]','$_POST[password]','')") or die (mysql_error());
		?>
        <script language="javascript">
		alert("Details successfully uploaded");
		location = 'index.php'
		</script>
        
        <?php
	
