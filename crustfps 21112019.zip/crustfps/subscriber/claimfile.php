<?php
session_start();
?>
<?php
include '../opendb.php';

$rer= mysql_query("select * from subscriber WHERE reg = '$_SESSION[username]'")or die(mysql_error());
while ($ter=mysql_fetch_array($rer)){
$name=$ter['name'];
$surname=$ter['surname'];
$fone=$ter['fone'];
$email=$ter['email'];
$policy=$ter['policy'];
$add=$ter['address'];
$pik=$ter['pathe'];
$reg=$ter['reg'];
?>


<?php

include '../opendb.php';
  	if (!isset($_FILES['files']['tmp_name'])) {
	echo "shame";
	}

	else if (!isset($_FILES['pop']['tmp_name'])) {
	echo "shame";
	}

	else if (!isset($_FILES['bop']['tmp_name'])) {
	echo "shame";
	}


	else{


//1
	$file=$_FILES['files']['tmp_name'];
	$image= addslashes(file_get_contents($_FILES['files']['tmp_name']));
	$image_name= addslashes($_FILES['files']['name']);
	$image_size= getimagesize($_FILES['files']['tmp_name']);

	
		
			move_uploaded_file($_FILES["files"]["tmp_name"],"claim/" . $_FILES["files"]["name"]);
			
			$location="claim/" . $_FILES["files"]["name"];

//2
$fil=$_FILES['pop']['tmp_name'];
	$imag= addslashes(file_get_contents($_FILES['pop']['tmp_name']));
	$imag_name= addslashes($_FILES['pop']['name']);
	$imag_size= getimagesize($_FILES['pop']['tmp_name']);

	
		
			move_uploaded_file($_FILES["pop"]["tmp_name"],"claim/" . $_FILES["pop"]["name"]);
			
			$locat="claim/" . $_FILES["pop"]["name"];



//3

$file=$_FILES['bop']['tmp_name'];
	$image= addslashes(file_get_contents($_FILES['bop']['tmp_name']));
	$image_name= addslashes($_FILES['bop']['name']);
	$image_size= getimagesize($_FILES['bop']['tmp_name']);

	
		
			move_uploaded_file($_FILES["bop"]["tmp_name"],"claim/" . $_FILES["bop"]["name"]);
			
			$loc="claim/" . $_FILES["bop"]["name"];

$qiqi= mysql_query("select * from premium WHERE policyNo = '$_SESSION[username]'")or die(mysql_error());
while ($taf=mysql_fetch_array($qiqi)){
$id=$taf['id'];
$amt=$taf['amt'];
$policyNo=$taf['policyNo'];
$cover=$taf['cover'];


				$status = "Pending";
			
mysql_query("insert into claim values('','$reg','$name','$surname','$location','$locat','$loc','$cover','$status')")or die(mysql_error());
				
				}	
			}
	
}

?>
        <script language="javascript">
		alert("Claim Request Sent");
		location = 'index.php'
		</script>	








