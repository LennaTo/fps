<?php
session_start();	
include '../opendb.php';

		
	mysql_query("INSERT INTO policy (id,type,amt)
VALUES
('','$_POST[type]','$_POST[amt]')") or die (mysql_error());
		?>
        <script language="javascript">
		alert("Policy successfully Added");
		location = 'index.php'
		</script>
        
        <?php
	
