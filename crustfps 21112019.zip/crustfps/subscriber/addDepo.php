<?php
error_reporting(0);
session_start();


include 'opendb.php';
$username=$_SESSION['username'];
$rs = mysql_query("select * from subscriber where reg = '$username'")or die(mysql_error());

while($row = mysql_fetch_array($rs))
{
$policy=$row['policy'];
$name=$row['name'];
$surname=$row['surname'];
$idnum=$row['reg'];
$usernames= $name." ".$surname;
}
?>



<?php

	mysql_query("INSERT INTO depend (id,policyNo,name,surname,rship,policy)
VALUES
('','$idnum','$_POST[name]','$_POST[surname]','$_POST[rship]','$policy')") or die (mysql_error());
		?>
        <script language="javascript">
		alert("Dependent successfully Added");
		location = 'index.php'
		</script>
      ?>