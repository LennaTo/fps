<?php
session_start();	
include '../opendb.php';

		
	mysql_query("INSERT INTO subscriber (reg,name,surname,fone,user,password,email)
VALUES
('$_POST[reg]','$_POST[name]','$_POST[surname]','$_POST[fone]','$_POST[user]','$_POST[password]','$_POST[email]')") or die (mysql_error());
		?>
        <script language="javascript">
		alert("Details successfully uploaded");
		location = 'index.php'
		</script>
        
  
	
