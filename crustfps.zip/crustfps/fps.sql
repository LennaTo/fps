-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Nov 08, 2019 at 10:12 AM
-- Server version: 5.1.36
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `fps`
--

-- --------------------------------------------------------

--
-- Table structure for table `agents`
--

CREATE TABLE IF NOT EXISTS `agents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `agentCode` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `surname` varchar(255) NOT NULL,
  `clents` int(11) NOT NULL,
  `commission` varchar(255) NOT NULL,
  `rate` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `agents`
--


-- --------------------------------------------------------

--
-- Table structure for table `claim`
--

CREATE TABLE IF NOT EXISTS `claim` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `policyNo` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `surname` varchar(255) NOT NULL,
  `natID` varchar(255) NOT NULL,
  `proof` varchar(255) NOT NULL,
  `burial` varchar(255) NOT NULL,
  `claim` int(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=22 ;

--
-- Dumping data for table `claim`
--

INSERT INTO `claim` (`id`, `policyNo`, `name`, `surname`, `natID`, `proof`, `burial`, `claim`, `status`) VALUES
(1, 'FPS199922A', 'Mako', 'hodzongi', 'claim/64513715_2329697937285500_767717492830240768_o.jpg', 'claim/Capture.PNG', 'claim/name.png', 0, 'Approved'),
(8, 'FPS199922A', 'Mako', 'hodzongi', 'claim/unnamed.jpg', 'claim/cover.jpg', 'claim/images.jpg', 15000, 'Pending'),
(7, 'CC19109V', 'linda', 'chishakwe', 'claim/Screenshot (1).png', 'claim/Screenshot (2).png', 'claim/Screenshot (3).png', 9000, 'pending'),
(11, 'CC199459', 'BELINDA', 'LUNGU', 'claim/Number 5.PNG', 'claim/TEST SCORE.PNG', 'claim/number 1.PNG', 35000, 'Pending'),
(12, 'ec191401H', 'desmond', 'dube', 'claim/Screen Cap (5).JPG', 'claim/Poster.jpg', 'claim/folder.jpg', 35000, 'Pending'),
(13, 'CC191435B', 'Letwin', 'Tembo', 'claim/IMG-20190115-WA0000.jpg', 'claim/IMG-20190309-WA0008.jpg', 'claim/IMG-20190502-WA0017.jpg', 35000, 'Pending'),
(17, 'CC191435B', 'Letwin', 'Tembo', 'claim/IMG-20190502-WA0007.jpg', 'claim/IMG-20190502-WA0021.jpg', 'claim/IMG-20191002-WA0005.jpg', 35000, 'Approved'),
(21, 'CC199459', 'BELINDA', 'LUNGU', 'claim/food02d.jpg', 'claim/food03d.jpg', 'claim/food02.jpg', 35000, 'Pending');

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE IF NOT EXISTS `comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reg` varchar(255) NOT NULL,
  `comment` varchar(25555) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`id`, `reg`, `comment`) VALUES
(1, 'FPS199922A', 'ui9nh,'),
(2, 'FPS199922A', 'volume boe here'),
(3, 'CC194895K', 'gOOD SERVICES .. KEEP UP THE GOOD WORK'),
(4, 'ec191401H', 'so far so good');

-- --------------------------------------------------------

--
-- Table structure for table `company`
--

CREATE TABLE IF NOT EXISTS `company` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `suffix` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `company`
--

INSERT INTO `company` (`id`, `name`, `suffix`, `phone`, `address`) VALUES
(1, 'Old mutual', 'om', '775125004', 'harare'),
(2, 'nyaradzo', 'ny', '0732125004', 'harare'),
(3, 'CRUST CORE', 'CC', '7123562158', 'GWERU'),
(4, 'ecocash', 'ec', '0778544998', 'masasa, harare');

-- --------------------------------------------------------

--
-- Table structure for table `depend`
--

CREATE TABLE IF NOT EXISTS `depend` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `policyNo` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `surname` varchar(255) NOT NULL,
  `rship` varchar(255) NOT NULL,
  `policy` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `depend`
--

INSERT INTO `depend` (`id`, `policyNo`, `name`, `surname`, `rship`, `policy`) VALUES
(1, 'FPS199922A', 'Inasem', 'Hodzongi', 'Father', 'Basic'),
(2, 'FPS199922A', 'keylar', 'chioto', 'Daughter', 'Basic'),
(4, 'FPS199922A', 'Melody', 'Ngorima', 'Mother', 'Basic'),
(5, 'CC19109V', 'clive', 'kasichi', 'Son', 'Platnum'),
(6, 'CC194895K', 'martin', 'rubaya', 'Father', 'Basic'),
(7, 'CC194895K', 'robert', 'chabata', 'Nephew', 'Basic'),
(8, 'CC199459', 'martha', 'kadoom', 'Daughter', 'Standard'),
(9, 'ec191401H', 'vusa', 'dube', 'Son', 'Standard'),
(10, 'CC191435B', 'Letwin', 'Tembo', 'Owner', 'Standard'),
(11, 'CC191435B', 'Edwin', 'Sibanda', 'Brother', 'Standard');

-- --------------------------------------------------------

--
-- Table structure for table `mesg`
--

CREATE TABLE IF NOT EXISTS `mesg` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `msg` varchar(255) NOT NULL,
  `time` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `mesg`
--

INSERT INTO `mesg` (`id`, `name`, `msg`, `time`) VALUES
(1, 'Vusa Dube', 'Admin here', '2019-11-07 23:23:34');

-- --------------------------------------------------------

--
-- Table structure for table `policy`
--

CREATE TABLE IF NOT EXISTS `policy` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  `premium` int(11) NOT NULL,
  `cover` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `policy`
--

INSERT INTO `policy` (`id`, `type`, `premium`, `cover`) VALUES
(1, 'Lite', 5, 9000),
(2, 'Basic', 10, 15000),
(3, 'Standard', 20, 35000),
(4, 'Platnum', 70, 100000);

-- --------------------------------------------------------

--
-- Table structure for table `premium`
--

CREATE TABLE IF NOT EXISTS `premium` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `policyNo` varchar(255) NOT NULL,
  `depend` varchar(255) DEFAULT NULL,
  `amt` int(11) NOT NULL,
  `cover` int(11) DEFAULT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `premium`
--

INSERT INTO `premium` (`id`, `policyNo`, `depend`, `amt`, `cover`, `date`, `time`) VALUES
(1, 'FPS199922A', NULL, 10, 15000, '2019-10-26', '03:35:11'),
(2, 'FPS199922A', NULL, 10, 15000, '2019-10-26', '03:35:11'),
(3, 'FPS199922A', NULL, 10, 15000, '2019-10-26', '03:35:11'),
(4, 'CC199459', NULL, 20, 35000, '2019-10-28', '09:33:52'),
(5, 'CC19109V', NULL, 70, 100000, '2019-10-28', '10:19:31'),
(6, 'ec191401H', NULL, 20, 35000, '2019-10-29', '02:30:19'),
(7, 'CC191435B', NULL, 20, 35000, '2019-11-07', '08:45:44'),
(8, 'CC191435B', NULL, 20, 35000, '2019-11-07', '08:45:44'),
(9, 'CC191435B', 'Owner', 20, 35000, '2019-11-07', '08:54:49'),
(10, 'CC191435B', 'Brother', 20, 35000, '2019-11-07', '08:54:49');

-- --------------------------------------------------------

--
-- Table structure for table `regs`
--

CREATE TABLE IF NOT EXISTS `regs` (
  `reg` varchar(255) DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `regs`
--


-- --------------------------------------------------------

--
-- Table structure for table `rship`
--

CREATE TABLE IF NOT EXISTS `rship` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rship` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `rship`
--

INSERT INTO `rship` (`id`, `rship`) VALUES
(1, 'Son'),
(2, 'Daughter'),
(3, 'Father'),
(4, 'Mother');

-- --------------------------------------------------------

--
-- Table structure for table `subscriber`
--

CREATE TABLE IF NOT EXISTS `subscriber` (
  `reg` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `surname` varchar(255) NOT NULL,
  `sex` varchar(255) NOT NULL,
  `fone` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `user` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `policy` varchar(255) NOT NULL,
  `company` varchar(255) NOT NULL,
  `pathe` varchar(255) NOT NULL,
  `agent` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`reg`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `subscriber`
--

INSERT INTO `subscriber` (`reg`, `name`, `surname`, `sex`, `fone`, `address`, `user`, `password`, `email`, `policy`, `company`, `pathe`, `agent`) VALUES
('FPS199922A', 'Mako', 'hodzongi', 'Male', '03569545', '1663 MKoba 12 Gweru Zimbabwe', 'mako', 'mako', 'mako@crust.com', 'Basic', '', 'images/1.JPG', ''),
('CC19109V', 'linda', 'chishakwe', 'Female', '071235894', 'mabvuku', 'linda', 'linda', 'linda@gmail.com', 'Platnum', 'CRUST CORE', 'images/cover.jpg', ''),
('CC194895K', 'RUSO', 'SIBANDA', 'Male', '071254863', 'RBZ', 'RUSO', 'RUSO', 'RUSO@GMAIL.COM', 'Basic', 'CRUST CORE', '../subscriber/images/72065391_10162268847090262_8993994334839767040_n.jpg', ''),
('CC199459', 'BELINDA', 'LUNGU', 'Female', '077796543', 'GREENDALE', 'BELINDA', 'BELINDA', 'BELINDA@GMAIL.COM', 'Standard', 'CRUST CORE', '../subscriber/images/72039238_1591433987674529_6169470248664694784_n.jpg', ''),
('ec191401H', 'desmond', 'dube', 'Male', '0778654234', 'greencroft, ', 'vybrant', 'vybrant', 'vybrant@cars.net', 'Standard', 'ecocash', '../subscriber/images/Screen Cap (1).JPG', ''),
('', '', '', '', '', '', '', '', '', '', '', '', NULL),
('CC191435B', 'Letwin', 'Tembo', 'Female', '0789564231', 'Kwekwe', 'leti', 'leti', 'leti@gmail.com', 'Standard', 'CRUST CORE', '../subscriber/images/IMG-20190206-WA0007.jpg', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `company` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `surname` varchar(255) DEFAULT NULL,
  `contact` int(25) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `sex` varchar(255) DEFAULT NULL,
  `access` int(25) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=18 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`company`, `name`, `surname`, `contact`, `email`, `sex`, `access`, `username`, `password`, `id`) VALUES
('nyaradzo', 'LennaTo', 'Takashi', 773747838, 'tate@gmail.com', 'Male', 0, 'admin', 'admin', 1),
('CRUST CORE', 'Trust', 'Matanga', 772273744, 'trust@gmail.com', 'Female', 1, 'head', 'head', 2),
('nyaradzo', 'James', 'White', 776665556, 'james@yahoo.com', 'Male', 2, 'james', 'james', 3),
('CRUST CORE', 'Lenie', 'Moyo', 773384756, 'leni@yahoo.com', 'Male', 3, 'leni', 'leni', 4),
('Old mutual', 'wellington', 'ganzio', 2147483647, 'welly@crustcore.com', 'male', 5, 'welly', 'welly', 5),
('CRUST CORE', 'teddy', 'magwere', 2147483647, 'teddy@gmail.com', 'male', 4, 'teddy', 'teddy', 6),
('Old mutual', 'esilida', 'hodzongi', 732125004, 'essy@gmail.com', 'Female', 1, 'essy', 'essy', 7),
('Old mutual', 'ranga', 'maggie', 732125004, 'ranga@crustfps.com', 'Male', 3, 'ranga', 'ranga', 9),
('ecocash', 'martin', 'rubaya', 775200500, 'martin@econet.net', 'Male', 2, 'matso', 'matso', 13),
('nyaradzo', 'LAWRENCE', 'MUPARUTSA', 2147483647, 'uchihas327@gmail.com', 'Male', 2, 'lawrie', 'lawrie', 10),
('ecocash', 'strive', 'masiyiwa', 775300800, 'strive@econet.net', 'Male', 1, 'strive', 'strive', 12),
('ecocash', 'getrude', 'machobo', 775700100, 'getty@econet.net', 'Female', 3, 'getty', 'getty', 14),
('', '', '', 0, '', '', 0, '', '', 15),
(NULL, '', '', 0, '', '', 0, '', '', 16),
('CRUST CORE', 'Vusa', 'Dube', 2147483647, 'vusa@gmail.com', 'Male', 2, 'dubes', 'dubes', 17);
