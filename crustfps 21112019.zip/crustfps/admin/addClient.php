<!DOCTYPE html>
<html dir="ltr" lang="en-US"><head><!-- Created by Artisteer v4.3.0.60858 -->
    <meta charset="utf-8">
    <title>Create User</title>
    <meta name="viewport" content="initial-scale = 1.0, maximum-scale = 1.0, user-scalable = no, width = device-width">

    <!--[if lt IE 9]><script src="https://html5shiv.googlecode.com/svn/trunk/html5.js"></script><![endif]-->
    <link rel="stylesheet" href="style.css" media="screen">
    <!--[if lte IE 7]><link rel="stylesheet" href="style.ie7.css" media="screen" /><![endif]-->
    <link rel="stylesheet" href="style.responsive.css" media="all">


    <script src="jquery.js"></script>
    <script src="script.js"></script>
    <script src="script.responsive.js"></script>



<style>.art-content .art-postcontent-0 .layout-item-0 { padding-right: 10px;padding-left: 10px;  }
.ie7 .art-post .art-layout-cell {border:none !important; padding:0 !important; }
.ie6 .art-post .art-layout-cell {border:none !important; padding:0 !important; }

</style></head>
<body>
<div id="art-main">
<header class="art-header">

    <div class="art-shapes">
        <div class="art-object309749862"></div>
<div class="art-textblock art-object647131190">
        <div class="art-object647131190-text-container">
        <div class="art-object647131190-text"><p style="color: #424511; font-size:22px;font-family:Georgia, 'Times New Roman', Times, Serif;font-weight:bold;font-style:normal;text-decoration:none;text-transform:uppercase"></p></div>
    </div>
    
</div>
            </div>






                        
                    
</header>
<nav class="art-nav">
    <div class="art-nav-inner">
    <ul class="art-hmenu"><li><a href="index.php" class="">Index</a></li><li><a href="vclient.php" class="">View Clients</a></li><li><a href="addStaff.php">Add Staff</a></li><li><a href="finstate.php">Financial Statement</a></li><li><a href="claims.php">View Claims</a></li><li><a href="chat/index.php">Online ChaT</a></li><li><a href="../logout.php">Log Out</a></li></ul> 
        </div>
    </nav>
<div class="art-sheet clearfix">
            <div class="art-layout-wrapper">
                <div class="art-content-layout">
                    <div class="art-content-layout-row">
                        <div class="art-layout-cell art-sidebar1"><div class="art-vmenublock clearfix">
        <div class="art-vmenublockheader">
            <h3 class="t">Menu</h3>
        </div>
        <div class="art-vmenublockcontent">
<ul class="art-vmenu"><li><a href="index.php" class="">Index</a></li><li><a href="vclient.php" class="">View Clients</a></li><li><a href="addStaff.php">Add Staff</a></li><li><a href="finstate.php">Financial Statement</a></li><li><a href="claims.php">View Claims</a></li><li><a href="chat/index.php">Online ChaT</a></li><li><a href="../logout.php">Log Out</a></li></ul>
                
        </div>
</div></div>
                        <div class="art-layout-cell art-content"><article class="art-post art-article">
                                <div class="art-postmetadataheader">
                                        <h2 class="art-postheader">ADD USER</h2>
                                                            
                                    </div>
                                <div class="art-postcontent art-postcontent-0 clearfix"><div class="art-content-layout">
    <div class="art-content-layout-row">
    <div class="art-layout-cell layout-item-0" style="width: 100%" >
        <form action="adde.php" method="post"  enctype="multipart/form-data" name="addroom" onSubmit="MM_validateForm('comment','','R');return document.MM_returnValue" >
	   
	  
	  <table width="70%" border="0" align="center" cellpadding="0" cellspacing="5" >
<tbody>
	            <tr align="center">
	        <td colspan="2" class="style8 style2 style9"><p align="center">Create user</p>
       	          </td>
	            <tr>
      <td>Name</td>
      <td>
        <input name="name" type="text" id="name" size="30" onKeyPress="return lettersOnly(event)" required=required  />       </td>
        </tr>
          <tr>
            <td width="267">Surname</td>
            <td width="287">
            <input name="surname" type="text" id="surname" size="30" onKeyPress="return lettersOnly(event)" required=required  />              </td>
    </tr>
          
           <tr>
            <td>Sex</td>
            <td>
              <select name="sex" size="1"><option value="Male">male</option><option value="Female">female</option></select>            </td>
          </tr><td>Access Level</td>
            <td>
              <select name="access" size="1">
			  <option value="4">Subscriber</option>
			  <option value="5">Agent</option>
			  </select>            
			  </td>
          </tr>
          <tr>
            <td>Contact Phone Number</td>
            <td> 
              <input name="contact" type="text" size="30" id="contact" maxlength="12" required=required />            </td>
          </tr><td>Username</td>
            <td>
              <input name="username" type="text" size="30" id="contact" maxlength="12"  required=required />            </td>
          </tr><td>Password</td>
            <td>
              <input name="password" type="password" size="30" id="contact" maxlength="12" required=required  />            </td>
          </tr>
          <tr>
            <td>E-Mail Address</td>
            <td>
             <input name="email" type="email" size="30" id="contact"  required=required />             </td>
          </tr><td>&nbsp;</td>
       <td><input type="submit" name="submit" value="Store Details" /></td>
          <tr>
          </tr></td>                     
        </tbody>
      </table>
	 
</form>
    </div>
    </div>
</div>
</div>


</article></div>
                    </div>
                </div>
            </div>
    </div>
<footer class="art-footer">
  <div class="art-footer-inner">
<p>Copyright © 2019, Funeral Policy System. All Rights Reserved.</p>
    <p class="art-page-footer">
    </p>
  </div>
</footer>

</div>


</body></html>