<!DOCTYPE html>
<html dir="ltr" lang="en-US"><head><!-- Created by Artisteer v4.3.0.60858 -->
    <meta charset="utf-8">
    <title>Claim</title>
    <meta name="viewport" content="initial-scale = 1.0, maximum-scale = 1.0, user-scalable = no, width = device-width">

    <!--[if lt IE 9]><script src="https://html5shiv.googlecode.com/svn/trunk/html5.js"></script><![endif]-->
    <link rel="stylesheet" href="style.css" media="screen">
    <!--[if lte IE 7]><link rel="stylesheet" href="style.ie7.css" media="screen" /><![endif]-->
    <link rel="stylesheet" href="style.responsive.css" media="all">


    <script src="jquery.js"></script>
    <script src="script.js"></script>
    <script src="script.responsive.js"></script>



<style>.art-content .art-postcontent-0 .layout-item-0 { padding-right: 10px;padding-left: 10px;  }
.ie7 .art-post .art-layout-cell {border:none !important; padding:0 !important; }
.ie6 .art-post .art-layout-cell {border:none !important; padding:0 !important; }

</style></head>
<body>
<div id="art-main">
<header class="art-header">

    <div class="art-shapes">
        <div class="art-object309749862"></div>
<div class="art-textblock art-object647131190">
        <div class="art-object647131190-text-container">
        <div class="art-object647131190-text"><p style="color: #424511; font-size:22px;font-family:Georgia, 'Times New Roman', Times, Serif;font-weight:bold;font-style:normal;text-decoration:none;text-transform:uppercase"></p></div>
    </div>
    
</div>
            </div>






                        
                    
</header>
<nav class="art-nav">
    <div class="art-nav-inner">
    <ul class="art-hmenu"><li><a href="index.php" class="">Home</a></li><li><a href="addDep.php" class="">Add Dependent</a></li><li><a href="claim.php" class="">Claim</a></li><li><a href="payp.php">Pay Premium</a></li><li><a href="moola.php">Account Statement</a></li><li><a href="../logout.php">Log Out</a></li></ul> 
        </div>
    </nav>
<div class="art-sheet clearfix">
            <div class="art-layout-wrapper">
                <div class="art-content-layout">
                    <div class="art-content-layout-row">
                        <div class="art-layout-cell art-sidebar1"><div class="art-vmenublock clearfix">
        <div class="art-vmenublockheader">
            <h3 class="t">Navigation</h3>
        </div>
        <div class="art-vmenublockcontent">
<ul class="art-vmenu"><li><a href="index.php" class="">Home</a></li><li><a href="addDep.php" class="">Add Dependent</a></li><li><a href="claim.php" class="">Claim</a></li><li><a href="viewclaim.php" class="">View Claims</a></li><li><a href="comment.php" class="">Comment</a></li><li><a href="moola.php">Account Statement</a></li><li><a href="../logout.php">Log Out</a></li></ul>
                
        </div>
</div></div>
                        <div class="art-layout-cell art-content"><article class="art-post art-article">
                                <div class="art-postmetadataheader">
                                        <h2 class="art-postheader">Upload Claim Files</h2>
                                                            
                                    </div>
                                <div class="art-postcontent art-postcontent-0 clearfix"><div class="art-content-layout">
    <div class="art-content-layout-row">
    <div class="art-layout-cell layout-item-0" style="width: 100%" >


<form action="claimfile.php" method="post" enctype="multipart/form-data"/>
<table border="0" align="center" bgcolor="#999999">
    <tr>
<td>National ID:</td>   
    <td><input type="file" name="files" id="files" class="ed" required parten="required" /></td>

    </tr>
    <br />
    <tr>

<td>Proof Of last Payment:</td>   
    <td><input type="file" name="pop" id="pop" class="ed" required parten="required" /></td>

    </tr>
    <br />
    <tr>
<td>Burial Order/ Postmotem:</td>   
    <td><input type="file" name="bop" id="bop" class="ed" required parten="required" /></td>
    </tr>
    <br />
    <tr>
<td><input type="submit" value="Submit" /></td>
    </tr>
    <tr>
        NB:: Kindly give proper names for your files to avoid inconviniences...
    </tr>
    </table>
</form>


        <form action="addexec.php" method="post"  enctype="multipart/form-data" name="addroom" onSubmit="MM_validateForm('comment','','R');return document.MM_returnValue" >
	   
	  <?php

// php select option value from database

/*$hostname = "localhost";
$username = "root";
$password = "";
$databaseName = "fps";

// connect to mysql database

$connect = mysqli_connect($hostname, $username, $password, $databaseName);

// mysql select query
$query = "SELECT * FROM `policy`";

// for method 1

$result1 = mysqli_query($connect, $query);

// for method 2

$result2 = mysqli_query($connect, $query);

$options = "";

while($row2 = mysqli_fetch_array($result2))
{
    $options = $options."<option>$row2[1]</option>";
}

?>

<!DOCTYPE html>

<html>

    <head>

        <title> PHP SELECT OPTIONS FROM DATABASE </title>

        <meta charset="UTF-8">

        <meta name="viewport" content="width=device-width, initial-scale=1.0">

    </head>

    <body>

        <!--Method One-->

        <select>

            <?php while($row1 = mysqli_fetch_array($result1)):;?>

            <option value="<?php echo $row1[0];?>"><?php echo $row1[1];?></option>

            <?php endwhile;?>

        </select>
        
        <!-- Method Two -->

        <select>
            <?php echo $options; */  ?>
        </select>

    </body>

</html>

</form>
    </div>
    </div>
</div>
</div>


</article></div>
                    </div>
                </div>
            </div>
    </div>
<footer class="art-footer">
  <div class="art-footer-inner">
<p>Copyright © 2019, Funeral Policy System. All Rights Reserved.</p>
    <p class="art-page-footer">
    </p>
  </div>
</footer>

</div>


</body></html>