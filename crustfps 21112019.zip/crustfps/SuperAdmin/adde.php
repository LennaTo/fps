<?php
session_start();	
include '../opendb.php';

if($_POST['password']!=$_POST['cpass']){
   ?>
  <script language="javascript">
 alert("Password did not match with confrim password");
 location = 'regCo.php'
  </script>
  <?php
  exit;
   }
   if(strlen($_POST['password']) < 8 ){
   ?>
  <script language="javascript">
 alert("Password should be above 8 charactors");
 location = 'regCo.php'
  </script>
  <?php
  exit;
   }
   if(strlen($_POST['contact']) < 10 ){
   ?>
  <script language="javascript">
 alert("Please Enter a valid phone number");
 location = 'regCo.php'
  </script>
  <?php
  exit;
   }
   else{
		
	mysql_query("INSERT INTO users (company,name,surname,contact,email,sex,access,username,password,id)
VALUES
('$_POST[company]','$_POST[name]','$_POST[surname]','$_POST[contact]','$_POST[email]','$_POST[sex]','$_POST[access]','$_POST[username]','$_POST[password]','')") or die (mysql_error());
		?>
        <script language="javascript">
		alert("**New User has been Created Successfully**");
		location = 'index.php'
		</script>
        
        <?php } ?>
