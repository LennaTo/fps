<?php 
//session_start();
include '../opendb.php';
 $rs=mysql_query("select * from claim WHERE id='$_REQUEST[id]'") or die(mysql_error());
while($row = mysql_fetch_array($rs)){
$id=$row['id'];
$name=$row['name'];
$surname=$row['surname'];
$policyNo=$row['policyNo'];
$natID=$row['natID'];
$proof=$row['proof'];
$burial = $row['burial'];
$claim=$row['claim'];
$status=$row['status'];
mysql_query("UPDATE claim SET status = 'Approved' WHERE id = '$id'")
?>

<script language="javascript">
		alert("Claim has been Approved..!");
		location = 'index.php'
		</script>
		<?php } ?>