<!DOCTYPE html>
<html dir="ltr" lang="en-US"><head><!-- Created by Artisteer v4.3.0.60858 -->
    <meta charset="utf-8">
    <title>Policy Menu</title>
    <meta name="viewport" content="initial-scale = 1.0, maximum-scale = 1.0, user-scalable = no, width = device-width">

    <!--[if lt IE 9]><script src="https://html5shiv.googlecode.com/svn/trunk/html5.js"></script><![endif]-->
    <link rel="stylesheet" href="style.css" media="screen">
    <!--[if lte IE 7]><link rel="stylesheet" href="style.ie7.css" media="screen" /><![endif]-->
    <link rel="stylesheet" href="style.responsive.css" media="all">


    <script src="jquery.js"></script>
    <script src="script.js"></script>
    <script src="script.responsive.js"></script>


<style>.art-content .art-postcontent-0 .layout-item-0 { margin-top: 10px;margin-bottom: 10px;  }
.art-content .art-postcontent-0 .layout-item-1 { border-spacing: 10px 0px; border-collapse: separate;  }
.art-content .art-postcontent-0 .layout-item-2 { color: #737373; background: #2F89B6; padding: 0px;  }
.art-content .art-postcontent-0 .layout-item-3 { color: #737373; background: #A04661; padding-right: 10px;padding-left: 10px;  }
.art-content .art-postcontent-0 .layout-item-4 { color: #737373; background: #5B9121; padding-right: 10px;padding-left: 10px;  }
.art-content .art-postcontent-0 .layout-item-5 { color: #737373; background: #EB9500; padding-right: 10px;padding-left: 10px;  }
.art-content .art-postcontent-0 .layout-item-6 { padding-right: 10px;padding-left: 10px;  }
.art-content .art-postcontent-0 .layout-item-7 { background: ; padding-right: 10px;padding-left: 10px;  }
.art-content .art-postcontent-0 .layout-item-8 { margin-top: 0px;margin-right: 10px;margin-bottom: 20px;margin-left: 10px;  }
.art-content .art-postcontent-0 .layout-item-9 {  border-collapse: separate;  }
.ie7 .art-post .art-layout-cell {border:none !important; padding:0 !important; }
.ie6 .art-post .art-layout-cell {border:none !important; padding:0 !important; }

</style></head>
<body>
<div id="art-main">
<nav class="art-nav">
    <ul class="art-hmenu"><li><a href="../index.php" class="active">Home</a></li></ul> 
    </nav>
<header class="art-header">

    <div class="art-shapes">
        
            </div>

<h1 class="art-headline">
    <a href="/">Available</a>
</h1>
<h2 class="art-slogan">Policies</h2>





                        
                    
</header>
<div class="art-sheet clearfix">
            <div class="art-layout-wrapper">
                <div class="art-content-layout">
                    <div class="art-content-layout-row">
                        <div class="art-layout-cell art-content"><article class="art-post art-article">
                                
                                                
                <div class="art-postcontent art-postcontent-0 clearfix"><div class="art-content-layout-wrapper layout-item-0">
<div class="art-content-layout layout-item-1">
    <div class="art-content-layout-row">
    <div class="art-layout-cell layout-item-2" style="width: 25%" >
        <p style="text-align: center;"><img width="187" height="187" alt="" src="images/126.png" style="margin-top: 5px; margin-right: 0px; margin-bottom: 5px; margin-left: 0px; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px;" class=""></p>
        <h4>LITE COVER</h4>
    </div><div class="art-layout-cell layout-item-3" style="width: 25%" >
        <p style="text-align: center;"><img width="187" height="187" alt="" src="images/2016_04_08-direito_familiageralt-pixabay.com907x645.png" style="margin-top: 5px; margin-right: 0px; margin-bottom: 5px; margin-left: 0px; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px;" class=""></p>
        <h4>BASIC COVER</h4>
    </div><div class="art-layout-cell layout-item-4" style="width: 25%" >
        <p style="text-align: center;"><img width="187" height="187" alt="" src="images/Liberty-Funeral-cover-AV-01.jpg" style="margin-top: 5px; margin-bottom: 5px; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px;" class=""></p>
        <h4>STANDARD COVER</h4>
    </div><div class="art-layout-cell layout-item-5" style="width: 25%" >
        <p style="text-align: center;"><img width="187" height="187" alt="" src="images/life-insurance-hub.jpg" style="margin-top: 5px; margin-bottom: 5px; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px;" class=""></p>
        <h4>PLATINUM COVER</h4>
    </div>
    </div>
</div>
</div>
<div class="art-content-layout layout-item-1">
    <div class="art-content-layout-row">
    <div class="art-layout-cell layout-item-6" style="width: 25%" >
        <p>PREMIUM - $5</p><p><br></p><p>COVER &nbsp;- $9 000</p><p><br></p>
    </div><div class="art-layout-cell layout-item-6" style="width: 25%" >
        <p>PREMIUM - $10</p><p><br></p><p>COVER &nbsp;- $15 000</p>
    </div><div class="art-layout-cell layout-item-6" style="width: 25%" >
        <p>PREMIUM - $20</p><p><br></p><p>COVER &nbsp;- $35 000</p>
    </div><div class="art-layout-cell layout-item-7" style="width: 25%" >
        <p>PREMIUM - $70</p><p><br></p><p>COVER &nbsp;- $ 100 000</p>
    </div>
    </div>
</div>
<div class="art-content-layout-wrapper layout-item-8">
<div class="art-content-layout layout-item-9">
    <div class="art-content-layout-row">
    <div class="art-layout-cell layout-item-6" style="width: 76%" >
        <p><br></p>
    </div><div class="art-layout-cell layout-item-7" style="width: 24%" >
        <p><br></p>
    </div>
    </div>
</div>
</div>
</div>


</article></div>
                    </div>
                </div>
            </div>
    </div>
<footer class="art-footer">
  <div class="art-footer-inner">
<p>Copyright © 2019, Funeral Policy System. All Rights Reserved.<br>
<br></p>
    <p class="art-page-footer">
        
    </p>
  </div>
</footer>

</div>


</body></html>