     <?php
session_start();
?>
<?php
include 'opendb.php';

$rer= mysql_query("select * from users WHERE username = '$_SESSION[username]'")or die(mysql_error());
while ($ter=mysql_fetch_array($rer)){
$company=$ter['company'];
$name=$ter['name'];
$surname=$ter['surname'];
$contact=$ter['contact'];
$email=$ter['email'];
$sex=$ter['sex'];
$username=$ter['username'];
$password=$ter['password'];
$id=$ter['id'];



?>



<!DOCTYPE html>
<html dir="ltr" lang="en-US"><head><!-- Created by Artisteer v4.3.0.60858 -->
    <meta charset="utf-8">
    <title>Companies</title>
    <meta name="viewport" content="initial-scale = 1.0, maximum-scale = 1.0, user-scalable = no, width = device-width">

    <!--[if lt IE 9]><script src="https://html5shiv.googlecode.com/svn/trunk/html5.js"></script><![endif]-->
    <link rel="stylesheet" href="style.css" media="screen">
    <!--[if lte IE 7]><link rel="stylesheet" href="style.ie7.css" media="screen" /><![endif]-->
    <link rel="stylesheet" href="style.responsive.css" media="all">


    <script src="jquery.js"></script>
    <script src="script.js"></script>
    <script src="script.responsive.js"></script>



<style>.art-content .art-postcontent-0 .layout-item-0 { padding-right: 10px;padding-left: 10px;  }
.ie7 .art-post .art-layout-cell {border:none !important; padding:0 !important; }
.ie6 .art-post .art-layout-cell {border:none !important; padding:0 !important; }

</style></head>
<body>
<div id="art-main">
<header class="art-header">

    <div class="art-shapes">
        <div class="art-object309749862"></div>
<div class="art-textblock art-object647131190">
        <div class="art-object647131190-text-container">
        <div class="art-object647131190-text"><p style="color: #424511; font-size:22px;font-family:Georgia, 'Times New Roman', Times, Serif;font-weight:bold;font-style:normal;text-decoration:none;text-transform:uppercase"></p></div>
    </div>
    
</div>
            </div>






                        
                    
</header>
<nav class="art-nav">
    <div class="art-nav-inner">
    <ul class="art-hmenu"><li><a href="index.php" class="">Index</a></li><li><a href="addClient.php" class="">Add Client</a></li><li><a href="vClient.php" class="">View Clients</a></li><li><a href="finstate.php" class="">Financial Statement</a></li><li><a href="../logout.php">Log Out</a></li></ul> 
        </div>
    </nav>
<div class="art-sheet clearfix">
            <div class="art-layout-wrapper">
                <div class="art-content-layout">
                    <div class="art-content-layout-row">
                        <div class="art-layout-cell art-sidebar1"><div class="art-vmenublock clearfix">
        <div class="art-vmenublockheader">
            <h3 class="t">Navigation</h3>
        </div>
        <div class="art-vmenublockcontent">
<ul class="art-vmenu"><li><a href="index.php" class="">Index</a></li><li><a href="addClient.php" class="">Add Client</a></li><li><a href="vClient.php" class="">View Clients</a></li><li><a href="finstate.php" class="">Financial Statement</a></li><li><a href="../logout.php">Log Out</a></li></ul>
                
        </div>
</div></div>
                        <div class="art-layout-cell art-content"><article class="art-post art-article">
                                <div class="art-postmetadataheader">
                                        <h2 class="art-postheader">SUBSCRIBERS</h2>
                                                            
                                    </div>
                                <div class="art-postcontent art-postcontent-0 clearfix"><div class="art-content-layout">
    <div class="art-content-layout-row">
    <div class="art-layout-cell layout-item-0" style="width: 100%" >
        <table width="100%" border="0" bgcolor="#FFFFFF">
					  <tr> 
                                   <td bgcolor="#CCCCCC" width="119"><font color="#000000">SUBSCRIBER ID</font></td>
                                   <td bgcolor="#CCCCCC" width="119"><font color="#000000">NAME</font></td>
                                   <td bgcolor="#CCCCCC" width="119"><font color="#000000">SURNAME</font></td>
                                   <td bgcolor="#CCCCCC" width="119"><font color="#000000">CONTACT</font></td>
                                   <td bgcolor="#CCCCCC" width="119"><font color="#000000">EMAIL ADDRESS</font></td>
								   <td bgcolor="#CCCCCC" width="119"><font color="#000000">POLICY</font></td>
                                    
						
                      <?php
					 	 
	  include 'opendb.php';
	 
      $rr= mysql_query("select * from company WHERE name like '%".$company."%' ")or die(mysql_error());
while ($tr=mysql_fetch_array($rr)){
$id=$ter['company'];
$name=$tr['name'];
$suffix=$tr['suffix'];
$phone=$tr['phone'];
$address=$tr['address'];
	  $rs=mysql_query("select * from subscriber WHERE reg like '%".$suffix."%'") or die(mysql_error());
while($row = mysql_fetch_array($rs)){
		$reg = $row['reg'];
		$name = $row['name'];
		$surname = $row['surname'];
		$fone = $row['fone'];
		$email= $row['email'];
        $policy= $row['policy'];
		
		

echo "<tr><td>".$reg."</a></font></td><td>".$name."</td><td>".$surname."</td><td>".$fone."</td><td>".$email."</td><td>".$policy."</td></tr>";
}}}
?>        </tr></table>

    </div>
    </div>
</div>
</div>


</article></div>
                    </div>
                </div>
            </div>
    </div>
<footer class="art-footer">
  <div class="art-footer-inner">
<p>Copyright © 2019, Funeral Policy System. All Rights Reserved.</p>
    <p class="art-page-footer">
    </p>
  </div>
</footer>

</div>


</body></html>