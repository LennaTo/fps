<?
date_default_timezone_set("Africa/Harare");
$zuva=date('y-m-d H:i:s');
echo $zuva;
?>