<?php
error_reporting(0);
session_start();


include 'opendb.php';
$username=$_SESSION['username'];
$rs = mysql_query("select * from users where username = '$username'")or die(mysql_error());

while($row = mysql_fetch_array($rs))
{
$name=$row['name'];
$surname=$row['surname'];
$idnum=$row['idnum'];
$usernames= $name." ".$surname;
}
?>


<!DOCTYPE html>
<html dir="ltr" lang="en-US"><head><!-- Created by Artisteer v4.3.0.60858 -->
    <meta charset="utf-8">
    <title>Policy Manager</title>
    <meta name="viewport" content="initial-scale = 1.0, maximum-scale = 1.0, user-scalable = no, width = device-width">

    <!--[if lt IE 9]><script src="https://html5shiv.googlecode.com/svn/trunk/html5.js"></script><![endif]-->
    <link rel="stylesheet" href="style.css" media="screen">
    <!--[if lte IE 7]><link rel="stylesheet" href="style.ie7.css" media="screen" /><![endif]-->
    <link rel="stylesheet" href="style.responsive.css" media="all">


    <script src="jquery.js"></script>
    <script src="script.js"></script>
    <script src="script.responsive.js"></script>



<style>.art-content .art-postcontent-0 .layout-item-0 { padding-right: 10px;padding-left: 10px;  }
.ie7 .art-post .art-layout-cell {border:none !important; padding:0 !important; }
.ie6 .art-post .art-layout-cell {border:none !important; padding:0 !important; }

</style></head>
<body>
<div id="art-main">
<header class="art-header">

    <div class="art-shapes">
        <div class="art-object309749862"></div>
<div class="art-textblock art-object647131190">
        <div class="art-object647131190-text-container">
        <div class="art-object647131190-text"><p style="color: #424511; font-size:22px;font-family:Georgia, 'Times New Roman', Times, Serif;font-weight:bold;font-style:normal;text-decoration:none;text-transform:uppercase"></p></div>
    </div>
    
</div>
            </div>






                        
                    
</header>
<nav class="art-nav">
    <div class="art-nav-inner">
    <ul class="art-hmenu"><li><a href="index.php" class="">Home</a></li><li><a href="viewCo.php">View Companies</a></li><li><a href="regCo.php">Create User</a></li><li><a href="regSub.php">Add Subscriber</a></li><li><a href="regCoo.php">Register company</a></li></li><li><a href="regP.php">Add Policy</a></li><li><a href="../logout.php">Logout</a></li></ul> 
        </div>
    </nav>
<div class="art-sheet clearfix">
            <div class="art-layout-wrapper">
                <div class="art-content-layout">
                    <div class="art-content-layout-row">
                        <div class="art-layout-cell art-sidebar1"><div class="art-vmenublock clearfix">
        <div class="art-vmenublockheader">
            <h3 class="t">Menu</h3>
        </div>
        <div class="art-vmenublockcontent">
<ul class="art-vmenu"><li><a href="index.php" class="">Index</a></li><li><a href="viewSub.php">View Subscribers</a></li><li><a href="viewCo.php">View Companies</a></li><li><a href="regP.php">Add Policy</a></li><li><a href="regCo.php">Create User</a></li><li><a href="regSub.php">Add Subscriber</a></li><li><a href="regCoo.php">Register company</a></li><li><a href="chat/index.php">Online ChaT</a></li><li><a href="backup.php">System BackUp</a></li><li><a href="../logout.php">Log ouT</a></li></ul>
        </div>
</div></div>
                        <div class="art-layout-cell art-content"><article class="art-post art-article">
                                <div class="art-postmetadataheader">                                                          
                                  <h4>Create a back Up of the current database:<br />
Save the most up todate information available in the database.....</h4>
<?php
error_reporting(0);
$database="fps";
define("DB_NAME", $database);

global $result;
$result="";

$backupFile = $database.date("_d_m_Y").'.sql'; //backup file name
$result .= "# MySQL Data Backup of ".$database."\n"; 
$result .= "# This was generated on " . date("d/m/Y") . "\n\n"; //just an information

$dbhandle= mysql_connect('localhost','root','') or die ("Could not connect");
$result="";
$result1="";

$tables = mysql_list_tables($database); 
for($i = 0; $i < mysql_num_rows($tables); $i++) 
{ 
$result1="";
$table = mysql_tablename ($tables, $i); 
$result .= "# Start of $table \n"; 
//for schema
$result .="DROP TABLE IF EXISTS `$table`;\n";   
$result .= "CREATE TABLE `$table` ( \n"; 
$result_fld = mysql_query( "SHOW FIELDS FROM ".$table, $dbhandle ); 

while($row1 = mysql_fetch_row($result_fld) ) {

$result.= "`".$row1[0]."`"." ".$row1[1]." " ;
if($row1[2]=="NO")
$result.=" NOT NULL ";
if(($row1[4]!=""))
$result.=" default `".$row1[4]."` ";
if($row1[5]!="")
$result.=" ".$row1[5]." ";
if($row1[3]=="PRI")
$result1.=" PRIMARY KEY (`".$row1[0]."`),\n";
if($row1[3]=="MUL")
$result1.=" KEY ".$row1[0]."("."`".$row1[0]."`"."),\n";
$result.=",\n";
} 
$result .= $result1; 
$result .= "\n);\n\n"; 

//for schema

$query = mysql_query("select * from $table"); 
$num_fields = mysql_num_fields($query); 
$numrow = mysql_num_rows($query); 

while( $row = mysql_fetch_array($query, MYSQL_NUM)) 
{ 
$result .= "INSERT INTO ".$table." VALUES("; 
for($j=0; $j<$num_fields; $j++) 
{ 
$row[$j] = addslashes($row[$j]); 
$row[$j] = str_replace("\n","\\n",$row[$j]); 
$row[$j] = str_replace("\r","",$row[$j]); 
if (isset($row[$j])) 
$result .= "\"$row[$j]\""; 
else 
$result .= "\"\""; 
if ($j<($num_fields-1)) 
$result .= ", "; 
} 
$result .= ");\n"; 
} 

if ($i+1 != mysql_num_rows($tables)) 
$result .= "\n"; 
} 
if((isset($_GET['action'])) && ($_GET['action'] == "save"))
{    ob_clean(); 
ob_start(); 
Header("Content-type: application/octet-stream"); 
Header("Content-Disposition: attachment; filename=$backupFile"); 
echo $result;
ob_end_flush();
echo "Backup Taken Successful!!!"; 
exit; 
}

?>
<table border=1 align="center" cellpadding="5" cellspacing="0" bordercolor="#C6D78C">
<form name='MyForm' method='post' action='backup.php?action=save'>
<tr bgcolor="#FFFFFF">
<td colspan = 2 align="center" ><input type='submit' name='submit' value='BACKUP'class = "butt1"></td>
</tr>
</form>
</table>
                </div>
            </div>
    </div>
<footer class="art-footer">
  <div class="art-footer-inner">
<p>Copyright © 2019, Funeral Policy System. All Rights Reserved.</p>
    <p class="art-page-footer">
    </p>
  </div>
</footer>

</div>


</body></html>