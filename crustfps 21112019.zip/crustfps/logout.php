<?php
session_start();
unset($_SESSION['id']);
unset($_SESSION['username']);
unset($_SESSION['logged']);
unset($_SESSION['password']);
unset($_SESSION['name']);
unset($_SESSION['surname']);
unset($_SESSION['email']);
unset($_SESSION['access']);
unset($_SESSION['sex']);
?>
<script language="javascript">
alert("Logout Success");
window.location="index.php";
</script>