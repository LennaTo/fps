<?php
error_reporting(0);
session_start();


include 'opendb.php';
$username=$_SESSION['username'];
$rs = mysql_query("select * from subscriber where reg = '$username'")or die(mysql_error());

while($row = mysql_fetch_array($rs))
{
$name=$row['name'];
$surname=$row['surname'];
$policyNo=$row['reg'];
$usernames= $name." ".$surname;
}
?>



<?php

	mysql_query("UPDATE claim SET status = 'Approved' WHERE policyNo = '$_POST[policyNo]'")
		?>
        <script language="javascript">
		alert("Claim Has Been Approved!");
		location = 'index.php'
		</script>
      ?>